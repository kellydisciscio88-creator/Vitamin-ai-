# Essential Vitamin & Mineral Interaction Rules

### Rule 1: Divalent Cations Compete for DMT1 Transporters
- **The Elements**: Calcium (Ca²⁺), Iron (Fe²⁺/Fe³⁺), Zinc (Zn²⁺), Magnesium (Mg²⁺).
- **The Problem**: When taken together in the same meal or capsule window, these minerals saturate the same intestinal receptors (Divalent Metal Transporter 1), slashing absorption by 40-70%.
- **Action**:
  - Take Iron and Zinc in the morning or early afternoon.
  - Take Calcium and Magnesium in the evening or separated by at least 2 hours.
  - Never take Iron with high-calcium dairy or calcium supplements.

### Rule 2: Fat-Soluble Vitamins Require Dietary Lipids
- **The Elements**: Vitamins A, D3, E, K1/K2, CoQ10, Astaxanthin, Omega-3s.
- **The Problem**: Taken on an empty stomach with plain water, up to 80% passes through without micellization or lymphatic transport.
- **Action**: Always take with at least 5-10g of healthy dietary fats (eggs, avocado, olive oil, nut butter, whole milk/yogurt).

### Rule 3: The Vitamin D3 + K2 + Magnesium Golden Triad
- **Vitamin D3** increases calcium absorption from the gut.
- **Vitamin K2 (MK-7)** activates osteocalcin and Matrix Gla Protein (MGP) to deposit that calcium into bones and teeth, preventing vascular and arterial calcification.
- **Magnesium** is the essential enzymatic co-factor required to convert inactive D3 into circulating 25-hydroxyvitamin D [25(OH)D] and active calcitriol [1,25(OH)2D].

### Rule 4: Coffee, Tea, and Tannin Blocking Window
- **Polyphenols and tannins** in coffee and black/green tea strongly bind to Iron and Zinc, creating insoluble complexes.
- **Action**: Wait 45-60 minutes after your morning coffee before taking mineral capsules.

### Rule 5: Circadian Sleep Hygiene for Supplements
- **Morning (Energizing)**: B-Complex, Vitamin D3, CoQ10, Cordyceps, Rhodiola.
- **Evening (Calming & Repair)**: Magnesium Glycinate/Threonate, L-Theanine, Apigenin, Glycine, Chamomile, Tart Cherry.
