# Personal Health Profiles

### Cory (Age 10)
- Gender: Male
- Weight: 72 lbs
- Height: 4'6"
- Dietary Style: Omnivore
- Goals: Cognitive Focus & Memory, Mitochondrial Energy, Immune Resilience
- Diagnosed Conditions / Sensitivities: Sensitive Stomach / GERD. High sensitivity to heavy pill stacks; prefers gentle absorption with food.
- Circadian Timing: Wake at 07:30, Sleep at 20:30

### Taylen (Age 9)
- Gender: Female
- Weight: 64 lbs
- Height: 4'3"
- Dietary Style: Low-Histamine
- Goals: Deep REM Sleep, Gut Barrier Repair, Histamine Tolerance
- Diagnosed Conditions / Sensitivities: Histamine Intolerance, Sensory Sensitive. Needs low visual clutter and calm pacing.
- Circadian Timing: Wake at 07:30, Sleep at 20:30
